class Story {
  final String id;
  final String title;
  final String imageUrl;

  // Optional: If you're using `coverImageUrl` or `author` directly
  String get coverImageUrl => imageUrl;
  String get author => 'Anonymous';

  Story({
    required this.id,
    required this.title,
    required this.imageUrl,
  });
}

class TrendingStory {
  final String id;
  final String coverImageUrl;
  final String title;
  final int views;
  final String author;

  TrendingStory({
    required this.id,
    required this.coverImageUrl,
    required this.title,
    required this.views,
    required this.author,
  });
}

class LatestUpdate {
  final String id;
  final String coverImageUrl;
  final String title;
  final String chapter;
  final String time;

  LatestUpdate({
    required this.id,
    required this.coverImageUrl,
    required this.title,
    required this.chapter,
    required this.time,
  });
}

class Chapter {
  final String title;
  final int chapterNumber;

  Chapter({
    required this.title,
    required this.chapterNumber,
  });
}

class StoryDetail {
  final String id;
  final String title;
  final String imageUrl;
  final String author;
  final int views;
  final String description;
  final List<String> genres;
  final List<Chapter> chapters;

  StoryDetail({
    required this.id,
    required this.title,
    required this.imageUrl,
    required this.author,
    required this.views,
    required this.description,
    required this.genres,
    required this.chapters,
  });
}

class HomePageData {
  final List<Story> newlyAddedStories;
  final List<TrendingStory> dailyTrending;
  final List<TrendingStory> weeklyTrending;
  final List<TrendingStory> monthlyTrending;
  final List<LatestUpdate> latestUpdates;

  HomePageData({
    required this.newlyAddedStories,
    required this.dailyTrending,
    required this.weeklyTrending,
    required this.monthlyTrending,
    required this.latestUpdates,
  });
}
