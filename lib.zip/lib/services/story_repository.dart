import 'dart:math';
import 'package:freemium_novels_app/models.dart';
import 'firebase_story_service.dart';
import 'firebase_article_service.dart';
import 'firebase_chapter_service.dart';

class StoryRepository {
  final StoryService _storyService = StoryService();
  final ArticleService _articleService = ArticleService();
  final ChapterService _chapterService = ChapterService();

  Future<HomePageData> getHomePageData() async {
    try {
      List<FirebaseStory> allStories = await _storyService.getAllStoriesDebug();
      List<FirebaseStory> publishedStories =
          allStories.where((s) => s.status == 'published').toList();

      List<FirebaseStory> firebaseNewlyAdded =
          await _storyService.getNewlyAddedStories(limit: 5);
      List<Story> newlyAdded =
          firebaseNewlyAdded.map((fs) => fs.toLegacyStory()).toList();

      final now = DateTime.now();
      final dailyFrom = now.subtract(const Duration(hours: 24));
      final weeklyFrom = now.subtract(const Duration(days: 7));
      final monthlyFrom = now.subtract(const Duration(days: 30));

      List<FirebaseChapter> allChapters = [];
      for (final story in allStories) {
        final chapters = await _chapterService.getChaptersByStoryId(story.id);
        allChapters.addAll(chapters);
      }

      int sumViews(List<FirebaseChapter> chapters, DateTime from) => chapters
          .where((c) => c.updatedAt.isAfter(from))
          .fold(0, (sum, c) => sum + (c.views ?? 0));

      List<TrendingStory> trendingBy(DateTime from) =>
          publishedStories.map((s) {
            final views = sumViews(
                allChapters.where((c) => c.storyId == s.id).toList(), from);
            return TrendingStory(
              id: s.id,
              coverImageUrl: s.coverImage.isNotEmpty
                  ? s.coverImage
                  : 'https://via.placeholder.com/150x220?text=${s.title.replaceAll(' ', '+').substring(0, 8)}',
              title: s.title,
              views: views,
            );
          }).toList()
            ..sort((a, b) => b.views.compareTo(a.views));

      final daily = trendingBy(dailyFrom).take(3).toList();
      final weekly = trendingBy(weeklyFrom).take(3).toList();
      final monthly = trendingBy(monthlyFrom).take(3).toList();

      final updates = publishedStories.toList()
        ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));

      List<LatestUpdate> latestUpdates = updates
          .take(10)
          .map((fs) => LatestUpdate(
                id: fs.id,
                coverImageUrl: fs.coverImage.isNotEmpty
                    ? fs.coverImage
                    : 'https://via.placeholder.com/150x220?text=${fs.title.replaceAll(' ', '+').substring(0, 8)}',
                title: fs.title,
                chapter: '',
                time: '${fs.views ?? 0} Views',
              ))
          .toList();

      return HomePageData(
        newlyAddedStories: newlyAdded,
        dailyTrending: daily,
        weeklyTrending: weekly,
        monthlyTrending: monthly,
        latestUpdates: latestUpdates,
      );
    } catch (_) {
      return _getMockHomePageData();
    }
  }

  Future<List<Story>> getStoriesForCategory(String category,
      {int page = 1, int storiesPerPage = 10}) async {
    try {
      List<FirebaseStory> firebaseStories =
          await _storyService.getStoriesByCategory(category);

      int start = (page - 1) * storiesPerPage;
      int end = (start + storiesPerPage).clamp(0, firebaseStories.length);

      if (start >= firebaseStories.length) return [];

      return firebaseStories
          .sublist(start, end)
          .map((fs) => fs.toLegacyStory())
          .toList();
    } catch (_) {
      return _getMockStoriesForCategory(category,
          page: page, storiesPerPage: storiesPerPage);
    }
  }

  Future<StoryDetail> getStoryDetail(
      String storyId, String title, String imageUrl) async {
    try {
      return await _storyService.getStoryDetail(storyId);
    } catch (_) {
      return _getMockStoryDetail(storyId, title, imageUrl);
    }
  }

  Future<String> getChapterContent(String storyId, int chapterNumber) async {
    try {
      return await _chapterService.getChapterContent(storyId, chapterNumber);
    } catch (_) {
      return _getMockChapterContent(chapterNumber);
    }
  }

  HomePageData _getMockHomePageData() {
    final newlyAdded = List.generate(
        5,
        (i) => Story(
            id: 'newly-$i',
            imageUrl: 'https://via.placeholder.com/150x220?text=Story${i + 1}',
            title: 'Newly Added Story ${i + 1}'));
    final daily = List.generate(
        3,
        (i) => TrendingStory(
            id: 'daily-$i',
            coverImageUrl:
                'https://via.placeholder.com/150x220?text=Daily${i + 1}',
            title: 'Daily Story ${i + 1}',
            views: (i + 1) * 1234));
    final weekly = List.generate(
        3,
        (i) => TrendingStory(
            id: 'weekly-$i',
            coverImageUrl:
                'https://via.placeholder.com/150x220?text=Weekly${i + 1}',
            title: 'Weekly Story ${i + 1}',
            views: (i + 1) * 2345));
    final monthly = List.generate(
        3,
        (i) => TrendingStory(
            id: 'monthly-$i',
            coverImageUrl:
                'https://via.placeholder.com/150x220?text=Monthly${i + 1}',
            title: 'Monthly Story ${i + 1}',
            views: (i + 1) * 3456));
    final updates = List.generate(
        10,
        (i) => LatestUpdate(
            id: 'update-$i',
            coverImageUrl:
                'https://via.placeholder.com/150x220?text=Update${i + 1}',
            title: 'Updated Story ${i + 1}',
            chapter: 'Chapter ${i + 15}',
            time: '${i + 1}h ago'));

    return HomePageData(
      newlyAddedStories: newlyAdded,
      dailyTrending: daily,
      weeklyTrending: weekly,
      monthlyTrending: monthly,
      latestUpdates: updates,
    );
  }

  Future<List<Story>> _getMockStoriesForCategory(String category,
      {int page = 1, int storiesPerPage = 10}) async {
    await Future.delayed(const Duration(seconds: 1));
    final prefix = category == "Originals" ? "Originals" : "Fan-Fiction";
    final total = category == "Originals" ? 25 : 15;
    int start = (page - 1) * storiesPerPage;
    int end = (start + storiesPerPage).clamp(0, total);
    if (start >= total) return [];
    return List.generate(end - start, (i) {
      int idx = start + i;
      return Story(
        id: '$prefix-$idx',
        title: '$prefix Story ${idx + 1}',
        imageUrl: 'https://via.placeholder.com/150x220?text=$prefix+${idx + 1}',
      );
    });
  }

  StoryDetail _getMockStoryDetail(
      String storyId, String title, String imageUrl) {
    final chapters = List.generate(
        10,
        (i) => Chapter(
            title: 'Chapter ${i + 1}: The Adventure Continues',
            chapterNumber: i + 1));
    return StoryDetail(
      id: storyId,
      title: title,
      imageUrl: imageUrl,
      author: 'Anonymous Author',
      views: Random().nextInt(10000) + 1000,
      description:
          'This is an exciting story about adventures, mysteries, and unforgettable characters.',
      genres: ['Adventure', 'Mystery', 'Romance'],
      chapters: chapters,
    );
  }

  String _getMockChapterContent(int chapterNumber) {
    return '''
Chapter $chapterNumber: The Adventure Continues

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua...
    ''';
  }
}
