import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/story_repository.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final StoryRepository _storyRepo = StoryRepository();
  List<Story> _trendingStories = []; // ✅ Use the correct model
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    loadTrendingStories();
  }

  Future<void> loadTrendingStories() async {
    try {
      List<Story> stories =
          await _storyRepo.getTrendingStories(); // ✅ Correct return type
      setState(() {
        _trendingStories = stories;
        _isLoading = false;
      });
    } catch (e) {
      print('Failed to load trending stories: $e');
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Trending Stories'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _trendingStories.isEmpty
              ? const Center(child: Text('No trending stories found.'))
              : ListView.builder(
                  itemCount: _trendingStories.length,
                  itemBuilder: (context, index) {
                    final story = _trendingStories[index];
                    return ListTile(
                      leading: story.coverImageUrl != null
                          ? Image.network(story.coverImageUrl!,
                              width: 60, fit: BoxFit.cover)
                          : const Icon(Icons.book),
                      title: Text(story.title),
                      subtitle: Text('By ${story.author}'),
                      onTap: () {
                        // Navigate to story detail screen if needed
                      },
                    );
                  },
                ),
    );
  }
}
